// '/template' 경로로 요청했을 때 template.ejs 파일을 렌더링하는 코드를 작성하세요.
