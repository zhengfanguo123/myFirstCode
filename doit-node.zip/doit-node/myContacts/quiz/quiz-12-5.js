// userMode.js의 사용자 모델을 참고하여 사용자 등록 API를 작성하세요.
// name과 email, password를 사용해서 사용자를 등록합니다.
