//  Node.js에서 ‘name’ 키의 값을 ‘Kim’으로 설정하는 쿠키 설정 코드를 작성하세요.

res.cookie("name", "Kim", { httpOnly: true });
