// Node.js의 setTimeout 함수를 사용해서 “Hello Node!” 메시지를 2초 후에 출력하는 코드를 작성하세요.

setTimeout( () => {
  console.log("Hello Node!");
}, 2000);