// 동기 처리하기

console.log("첫번째 작업");
console.log(`두번째 작업`);
console.log(`세번째 작업`);
