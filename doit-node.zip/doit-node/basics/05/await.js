// async ... awiat 연습하기  (결과 비교 파일 : 05\results\await.js)
