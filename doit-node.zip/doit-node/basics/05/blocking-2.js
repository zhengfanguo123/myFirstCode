// 서버에서 블로킹 I/O  (결과 비교 파일 : 05\results\blocking-2.js)

