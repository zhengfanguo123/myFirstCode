// fs 모듈의 readdirSync 함수 연습하기 ( 결과 비교 파일 : 03\results\list-1.js)
