// 파이프 연습하기 (결과 비교 파일 : 03\results\pipe.js)

