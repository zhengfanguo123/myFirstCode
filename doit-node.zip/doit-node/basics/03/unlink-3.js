// 비동기로 파일 삭제하기 - unlink 함수 (결과 비교 파일 : 03\results\unlink-3.js)

