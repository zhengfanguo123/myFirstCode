// 여러 계층의 디렉터리 만들기 - mkdir 함수의 recursive 옵션 (결과 비교 파일 : 03\results\dir-2.js)
