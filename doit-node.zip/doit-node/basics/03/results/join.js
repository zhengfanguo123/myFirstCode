const path = require("path");

const fullPath = path.join(__dirname, "assets", "test.txt");
console.log(fullPath);
