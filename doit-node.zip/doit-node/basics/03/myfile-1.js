const fs = require("fs");

fs.writeFileSync("hello.txt", "Hello, world!");
