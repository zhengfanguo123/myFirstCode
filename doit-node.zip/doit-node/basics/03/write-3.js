// 비동기로 파일 기록하기 -  writeFile 함수 (결과 비교 파일은 03\results\write-3.js)

