// 동기로 파일 기록하기 - existsSync 함수, writeFileSync 함수 (결과 비교 파일은 03\results\write-2.js)


