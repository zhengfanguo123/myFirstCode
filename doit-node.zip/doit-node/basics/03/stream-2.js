// 라이터블 스트림 연습하기 (결과 비교 파일 : 03\results\stream-2.js)
