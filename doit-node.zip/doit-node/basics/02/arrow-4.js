// 매개변수가 있는 화살표 함수를 더 간단하게 표현하기  (결과 비교 : 02\results\arrow-4.js)

// 화살표 함수
// let sum = (a, b) => { return a + b; };
// console.log(sum(100, 200));

// 화살표 함수를 좀더 간단하게
