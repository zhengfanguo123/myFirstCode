// 함수 선언과 호출을 동시에 

(function (a, b) {
  console.log(`두 수의 합: ${a + b}`);
})(100, 200); // 300