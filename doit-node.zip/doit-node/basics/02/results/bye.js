const bye = (name) => {
  console.log(`${name} 님, 안녕히 가세요.`);
};

module.exports = bye;
