const users = require("./users-3");
const hello = require("./hello");

console.log(users);
hello(users.user3);