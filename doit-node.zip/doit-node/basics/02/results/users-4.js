const user1 = "Kim";
const user2 = "Lee";
const user3 = "Choi";

export { user1, user2, user3 };
