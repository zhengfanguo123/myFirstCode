const user = require("./user.js");
const bye = require("./bye.js");

bye(user);