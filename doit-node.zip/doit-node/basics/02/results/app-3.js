const user3 = require("./users-2.js");
const hello = require("./hello.js");

hello(user3); 
