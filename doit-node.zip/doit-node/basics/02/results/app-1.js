const user = require("./user.js");
const hello = require("./hello.js");

hello(user);
