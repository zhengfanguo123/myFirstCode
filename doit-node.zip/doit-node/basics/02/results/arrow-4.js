// 매개변수가 있는 화살표 함수를 더 간단하게 표현하기

// 화살표 함수
// let sum = (a, b) => { return a + b; };
// console.log(sum(100, 200));

// 화살표 함수를 좀더 간단하게
let sum = (a, b) => a + b;
console.log(sum(100, 200)); // 300
