let num1 = 10;
let num2 = 20;

// 연결 연산자 사용
console.log(num1 + "과 " + num2 + "를 더하면 " + (num1 + num2) + "입니다.");
// 템플릿 리터럴 사용
console.log(`${num1}과 ${num2}를 더하면 ${num1 + num2}입니다.`);
