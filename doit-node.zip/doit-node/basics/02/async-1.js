// 중간에 시간 걸리는 작업이 있을 경우  (결과 비교: 02\results\async-1.js)
