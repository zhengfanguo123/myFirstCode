// 프로미스를 사용해 피자 주문하기   (결과 비교: 02\results\promise.js)

