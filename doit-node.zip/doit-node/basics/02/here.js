console.log(`현재 모듈이 있는 폴더: ${__dirname}`);
console.log(`현재 모듈의 파일명 : ${__filename}`);