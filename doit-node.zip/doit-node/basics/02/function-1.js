// 함수 선언하고 호출하기  (결과 비교 파일 : 02\results\function-1.js)

// 함수 선언
function greeting(name) {
    console.log(`${name} 님, 안녕하세요?`);
}

// 함수 호출
greeting('홍길동');
