// 함수 표현식으로 선언하고 호출하기  (결과 비교 파일 : 02\results\function-2.js)

// 함수 선언
let greeting = function(name) {
    console.log(`${name} 님, 안녕하세요? `);
}

// 함수 호출
greeting('홍길동');