// catch - 프로미스에서 실패했을 때 (reject)  실행할 작업
// then - 프로미스에서 성공했을 때 (resolve) 실행할 작업