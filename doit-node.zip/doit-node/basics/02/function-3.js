// 함수 선언과 호출을 동시에 (결과 비교: 02\results\function-3.js)

(function(a,b) {
    console.log(`두 수의 합: ${a + b}`);
}(100, 200)) ;