// 아래 화살표 함수를 좀더 간단하게 표현하기  (결과 비교 : 02\results\arrow-2.js)

// 화살표 함수
// let sum = (a, b) => { return a + b; };

// 화살표 함수를 좀더 간단하게
let sum = (a, b) => a + b;

sum(100, 200); // 300
